======= Chups's sign pack EN-blue v1.0 =======

The resourcepack adds pictures for signs from the Minecraft Transit Railway (MTR) mod to the game.
The signs are inspired by Russian railways, but have been reinterpreted and changed.

By Chups

=======================================